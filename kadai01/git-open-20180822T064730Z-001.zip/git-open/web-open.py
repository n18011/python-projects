#!/usr/bin/python3

import webbrowser, csv, requests, bs4

csv_file = open('url.csv')
csv_reader = csv.reader(csv_file)
csv_date = list(csv_reader)


def searchName():
    user = input('>>> 表示したい人の名前を入力してください: ')
    for number in range(len(csv_date)):
        if user == csv_date[number][0]:
            return csv_date[number][1]




def gitURL(url):
    res = requests.get(url + '?tab=repositories')
    soup = bs4.BeautifulSoup(res.text, 'lxml')
    url_list = {}
    p = 1
    for tag in soup.find_all('h3'):
        if p > 2:
            urlname = tag.find('a').string.strip()
            url_list[urlname] = '{}/{}'.format(url, urlname)
        p += 1
    return url_list



def checkURL(url):
    for rep_name in url.keys():
        print(rep_name)

    user = input('>>> 何を表示しますか？: ')

    check = input('>>> 選択したものの中も確認しますか？(Yes or No): ')

    if check == 'Yes' or check == 'yes':
        deepCheck(url[user])
    else:
        webbrowser.open(url[user])



def deepCheck(url):
    res = requests.get(url)
    soup = bs4.BeautifulSoup(res.text, 'lxml')
    deep_url = {}
    for elem in soup.find_all('span', class_='css-truncate css-truncate-target'):
        content = elem.find('span').string.strip()
        href = elem.find('span').get('href')
        deep_url[content] = href
    print(deep_url)




if __name__ == '__main__':
    checkURL(gitURL(searchName()))
